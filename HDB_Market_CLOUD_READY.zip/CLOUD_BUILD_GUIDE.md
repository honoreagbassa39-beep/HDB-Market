# HDB Market — Compilation Cloud depuis un téléphone

## Service utilisé
Codemagic peut compiler un projet Flutter dans le cloud. Le dépôt doit être hébergé sur GitHub, GitLab ou Bitbucket.

## 1. Depuis l'iPhone
1. Créer/connecter un compte GitHub.
2. Créer un dépôt nommé `hdb-market`.
3. Importer tous les fichiers de ce ZIP dans le dépôt, en gardant `codemagic.yaml` à la racine.
4. Ouvrir Codemagic et connecter GitHub.
5. Ajouter le dépôt `hdb-market`.
6. Choisir le workflow `HDB Market Android APK`.
7. Lancer `Start new build`.

## 2. Identifiants Supabase
Dans Codemagic, ajouter deux variables d'environnement :
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`

Ne jamais mettre une clé `service_role` dans l'application mobile.

## 3. Résultat
Le workflow APK produit :
`build/app/outputs/flutter-apk/app-release.apk`

Pour Google Play, utiliser le workflow :
`HDB Market Android App Bundle`

Il produira :
`build/app/outputs/bundle/release/app-release.aab`

## Important
Le workflow génère automatiquement le dossier Android à partir du projet Flutter. L'APK de test peut être construit sans signature Play Store. Pour publier officiellement sur Google Play, il faudra ensuite configurer la signature Android et le compte Google Play.
