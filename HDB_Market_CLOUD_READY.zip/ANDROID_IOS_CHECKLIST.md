# Publication Android + iPhone
- Android: create signing key, application ID, Play Console listing, privacy policy, production Supabase URL/key.
- iPhone: Apple Developer account, Bundle ID, certificates/profiles, App Store Connect listing, privacy policy.
- Test login, catalogue, cart, checkout, payment callback, delivery and seller flows on physical devices.
- Replace all TODO payment/provider integrations before production.
