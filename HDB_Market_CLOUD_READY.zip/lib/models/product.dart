class Product {
  final String id, name;
  final double price;
  final String? imageUrl, description, category;
  final int stock;

  const Product({
    required this.id, required this.name, required this.price,
    this.imageUrl, this.description, this.category, this.stock=0,
  });

  factory Product.fromMap(Map<String,dynamic> m)=>Product(
    id:m['id'].toString(), name:m['name'] as String,
    price:(m['price'] as num).toDouble(),
    imageUrl:m['image_url'] as String?,
    description:m['description'] as String?,
    category:m['category'] as String?,
    stock:(m['stock'] as num?)?.toInt() ?? 0,
  );
}
