import 'package:supabase_flutter/supabase_flutter.dart';
class AuthService {
 final c=Supabase.instance.client;
 Future<void> signIn(String email,String password)=>c.auth.signInWithPassword(email:email,password:password);
 Future<void> signUp(String email,String password,String name)=>c.auth.signUp(email:email,password:password,data:{'full_name':name});
 Future<void> signOut()=>c.auth.signOut();
}
