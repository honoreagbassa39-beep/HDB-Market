import '../models/cart_item.dart';
import '../models/product.dart';

class CartService {
  static final instance=CartService._();
  CartService._();
  final List<CartItem> items=[];
  void add(Product p){ final i=items.where((x)=>x.product.id==p.id).firstOrNull;
    if(i!=null)i.quantity++;else items.add(CartItem(product:p));}
  void decrease(Product p){final i=items.where((x)=>x.product.id==p.id).firstOrNull;
    if(i==null)return;if(i.quantity>1)i.quantity--;else items.remove(i);}
  double get total=>items.fold(0,(s,i)=>s+i.subtotal);
  bool get isEmpty=>items.isEmpty;
}
