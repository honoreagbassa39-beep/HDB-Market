import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class PaymentService {
 final c=Supabase.instance.client;
 Future<void> pay(String orderId) async {
  final r=await c.functions.invoke('create-payment',body:{'order_id':orderId});
  final data=Map<String,dynamic>.from(r.data as Map);
  final url=data['payment_url'];
  if(url!=null)await launchUrl(Uri.parse(url),mode:LaunchMode.externalApplication);
 }
}
