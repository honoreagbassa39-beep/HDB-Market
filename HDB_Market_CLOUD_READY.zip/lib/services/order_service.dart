import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/cart_item.dart';
class OrderService {
 final c=Supabase.instance.client;
 Future<String> create(List<CartItem> items,{required String addressId,required double deliveryFee}) async {
  final u=c.auth.currentUser;if(u==null)throw Exception('Connecte-toi.');
  final total=items.fold<double>(deliveryFee,(s,i)=>s+i.subtotal);
  final row=await c.from('orders').insert({
   'user_id':u.id,'address_id':addressId,'total_amount':total,
   'delivery_fee':deliveryFee,'status':'pending',
   'tracking_code':'HDB-${DateTime.now().millisecondsSinceEpoch}'
  }).select('id').single();
  final id=row['id'];
  await c.from('order_items').insert(items.map((i)=>{'order_id':id,'product_id':i.product.id,'quantity':i.quantity,'unit_price':i.product.price}).toList());
  return id.toString();
 }
 Future<List<Map<String,dynamic>>> mine() async {
  final u=c.auth.currentUser;if(u==null)return[];
  return await c.from('orders').select().eq('user_id',u.id).order('created_at',ascending:false);
 }
}
