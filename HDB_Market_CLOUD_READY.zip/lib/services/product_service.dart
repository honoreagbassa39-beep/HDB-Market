import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/product.dart';
class ProductService {
 final c=Supabase.instance.client;
 Future<List<Product>> list({String? category,String? search}) async {
   var q=c.from('products').select().eq('active',true);
   if(category!=null&&category.isNotEmpty)q=q.eq('category',category);
   final rows=await q.order('created_at',ascending:false);
   var ps=rows.map<Product>((x)=>Product.fromMap(x)).toList();
   if(search!=null&&search.trim().isNotEmpty){
     final s=search.toLowerCase();
     ps=ps.where((p)=>p.name.toLowerCase().contains(s)).toList();
   }
   return ps;
 }
 Future<void> add({required String name,required double price,required int stock,String? category,String? imageUrl}) async {
   final u=c.auth.currentUser;if(u==null)throw Exception('Connecte-toi.');
   await c.from('products').insert({'seller_id':u.id,'name':name,'price':price,'stock':stock,'category':category,'image_url':imageUrl,'active':true});
 }
}
