import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AddressScreen extends StatefulWidget{const AddressScreen({super.key});@override State<AddressScreen> createState()=>_AddressScreenState();}
class _AddressScreenState extends State<AddressScreen>{
 final form=GlobalKey<FormState>(); final name=TextEditingController(),phone=TextEditingController(),city=TextEditingController(),district=TextEditingController(),details=TextEditingController();
 String country='TG';
 Future<String?> save()async{
  if(!form.currentState!.validate())return null; final u=Supabase.instance.client.auth.currentUser;if(u==null)throw Exception('Connecte-toi.');
  final id=DateTime.now().millisecondsSinceEpoch.toString();
  await Supabase.instance.client.from('addresses').insert({'id':id,'user_id':u.id,'full_name':name.text,'phone':phone.text,'country':country,'city':city.text,'district':district.text,'details':details.text});
  return id;
 }
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Livraison')),body:Form(key:form,child:ListView(padding:const EdgeInsets.all(16),children:[
  for(final x in [(name,'Nom complet'),(phone,'Téléphone'),(city,'Ville'),(district,'Quartier'),(details,'Repère / détails')]) TextFormField(controller:x.$1,decoration:InputDecoration(labelText:x.$2),validator:(v)=>v==null||v.isEmpty?'Obligatoire':null),
  DropdownButtonFormField<String>(value:country,items:const[DropdownMenuItem(value:'TG',child:Text('Togo')),DropdownMenuItem(value:'BJ',child:Text('Bénin')),DropdownMenuItem(value:'CI',child:Text('Côte d’Ivoire')),DropdownMenuItem(value:'GH',child:Text('Ghana'))],onChanged:(v)=>setState(()=>country=v??'TG'),decoration:const InputDecoration(labelText:'Pays')),
  const SizedBox(height:20),FilledButton(onPressed:()async{final id=await save();if(id!=null&&mounted)Navigator.pop(context,id);},child:const Text('Enregistrer et continuer'))
 ])));
}
