import 'package:flutter/material.dart';
class AdminDashboard extends StatelessWidget{const AdminDashboard({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Administration')),body:ListView(padding:const EdgeInsets.all(16),children:const[
 ListTile(leading:Icon(Icons.people),title:Text('Utilisateurs'),subtitle:Text('Gestion des comptes')),
 ListTile(leading:Icon(Icons.inventory),title:Text('Produits'),subtitle:Text('Modération et catégories')),
 ListTile(leading:Icon(Icons.receipt),title:Text('Commandes'),subtitle:Text('Suivi global')),
 ListTile(leading:Icon(Icons.payments),title:Text('Paiements'),subtitle:Text('Contrôle des transactions')),
 ListTile(leading:Icon(Icons.local_shipping),title:Text('Livraisons'),subtitle:Text('Gestion logistique')),
]);}}
