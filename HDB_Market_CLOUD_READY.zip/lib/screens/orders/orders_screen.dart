import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/payment_service.dart';
class OrdersScreen extends StatefulWidget{const OrdersScreen({super.key});@override State<OrdersScreen> createState()=>_OrdersScreenState();}
class _OrdersScreenState extends State<OrdersScreen>{
 Future<List<Map<String,dynamic>>> load()async{final u=Supabase.instance.client.auth.currentUser;if(u==null)return[];return await Supabase.instance.client.from('orders').select().eq('user_id',u.id).order('created_at',ascending:false);}
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Mes commandes')),body:FutureBuilder(future:load(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final rows=s.data as List;return ListView(children:[...rows.map((o)=>Card(child:ListTile(title:Text('Commande #${o['id'].toString().substring(0,8)}'),subtitle:Text('${o['status']} • ${o['total_amount']} FCFA'),trailing:o['status']=='pending'?TextButton(onPressed:()=>PaymentService().pay(o['id'].toString()),child:const Text('Payer')):const Icon(Icons.local_shipping))) ]);}));
}
