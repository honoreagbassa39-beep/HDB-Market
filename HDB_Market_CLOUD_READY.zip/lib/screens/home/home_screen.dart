import 'package:flutter/material.dart';
import '../../models/product.dart';
import '../../services/cart_service.dart';
import '../../services/product_service.dart';
import '../cart/cart_screen.dart';
import '../orders/orders_screen.dart';
import '../profile/profile_screen.dart';
import '../seller/seller_dashboard.dart';

class HomeScreen extends StatefulWidget{const HomeScreen({super.key});@override State<HomeScreen> createState()=>_HomeScreenState();}
class _HomeScreenState extends State<HomeScreen>{
 final cart=CartService.instance; final search=TextEditingController();
 int tab=0;
 Future<List<Product>> load()=>ProductService().list(search:search.text);
 @override Widget build(BuildContext context){
  final pages=[
   _catalog(),
   const OrdersScreen(),
   const SellerDashboard(),
   const ProfileScreen()
  ];
  return Scaffold(
   appBar: AppBar(title:const Text('HDB Market',style:TextStyle(fontWeight:FontWeight.bold))),
   body:pages[tab],
   floatingActionButton:FloatingActionButton(
    onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CartScreen())).then((_)=>setState((){})),
    child:Badge(label:Text('${cart.items.length}'),child:const Icon(Icons.shopping_cart))),
   bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),
    destinations:const[
     NavigationDestination(icon:Icon(Icons.storefront),label:'Accueil'),
     NavigationDestination(icon:Icon(Icons.receipt_long),label:'Commandes'),
     NavigationDestination(icon:Icon(Icons.sell),label:'Vendre'),
     NavigationDestination(icon:Icon(Icons.person),label:'Profil'),
    ]),
  );
 }
 Widget _catalog()=>Column(children:[
  Padding(padding:const EdgeInsets.all(12),child:TextField(controller:search,onSubmitted:(_)=>setState((){}),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Rechercher un produit',border:OutlineInputBorder()))),
  const Padding(padding:EdgeInsets.all(12),child:Align(alignment:Alignment.centerLeft,child:Text('Achète. Vends. Partout en Afrique.',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)))),
  Expanded(child:FutureBuilder<List<Product>>(future:load(),builder:(c,s){
   if(s.connectionState!=ConnectionState.done)return const Center(child:CircularProgressIndicator());
   final ps=s.data??[];
   if(ps.isEmpty)return const Center(child:Text('Aucun produit pour le moment.'));
   return ListView.builder(itemCount:ps.length,itemBuilder:(_,i){final p=ps[i];return Card(margin:const EdgeInsets.symmetric(horizontal:12,vertical:6),child:ListTile(
    leading:const CircleAvatar(child:Icon(Icons.shopping_bag)),title:Text(p.name),subtitle:Text('${p.price.toStringAsFixed(0)} FCFA • Stock ${p.stock}'),
    trailing:IconButton(icon:const Icon(Icons.add_shopping_cart),onPressed:p.stock>0?(){setState(()=>cart.add(p));}:null)));});
  }))
 ]);
}
