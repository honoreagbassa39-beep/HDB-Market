import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/auth_service.dart';
class ProfileScreen extends StatelessWidget{const ProfileScreen({super.key});@override Widget build(BuildContext c){final u=Supabase.instance.client.auth.currentUser;return ListView(padding:const EdgeInsets.all(20),children:[
 const Text('Mon profil',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),const SizedBox(height:12),
 Text(u?.email??'Non connecté'),const SizedBox(height:24),
 FilledButton(onPressed:()=>AuthService().signOut(),child:const Text('Se déconnecter')),
 const SizedBox(height:20),const Text('HDB Market • Marketplace Africa')
]);}}
