import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/product_service.dart';
class SellerDashboard extends StatefulWidget{const SellerDashboard({super.key});@override State<SellerDashboard> createState()=>_SellerDashboardState();}
class _SellerDashboardState extends State<SellerDashboard>{
 final n=TextEditingController(),p=TextEditingController(),s=TextEditingController(),cat=TextEditingController();
 Future<void> add()async{await ProductService().add(name:n.text,price:double.tryParse(p.text)??0,stock:int.tryParse(s.text)??0,category:cat.text);n.clear();p.clear();s.clear();setState((){});}
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
 const Text('Espace vendeur',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
 const SizedBox(height:12),TextField(controller:n,decoration:const InputDecoration(labelText:'Produit')),
 TextField(controller:p,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Prix FCFA')),
 TextField(controller:s,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Stock')),
 TextField(controller:cat,decoration:const InputDecoration(labelText:'Catégorie')),
 const SizedBox(height:12),FilledButton(onPressed:add,child:const Text('Publier le produit')),
 const SizedBox(height:24),const Text('Commandes vendeur',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
 FutureBuilder(future:Supabase.instance.client.from('orders').select('id,status,total_amount').limit(20),builder:(c,s)=>s.hasData?Column(children:[...(s.data as List).map((o)=>ListTile(title:Text('Commande ${o['id'].toString().substring(0,8)}'),subtitle:Text('${o['status']} • ${o['total_amount']} FCFA')))]):const SizedBox())
 ]);
}
