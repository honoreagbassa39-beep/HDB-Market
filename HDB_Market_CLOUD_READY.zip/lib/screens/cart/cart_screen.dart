import 'package:flutter/material.dart';
import '../../services/cart_service.dart';
import '../../services/order_service.dart';
import '../delivery/address_screen.dart';

class CartScreen extends StatefulWidget{const CartScreen({super.key});@override State<CartScreen> createState()=>_CartScreenState();}
class _CartScreenState extends State<CartScreen>{
 final cart=CartService.instance;
 Future<void> checkout()async{
  if(cart.isEmpty)return;
  final address=await Navigator.push<String>(context,MaterialPageRoute(builder:(_)=>const AddressScreen()));
  if(address==null)return;
  try{
   await OrderService().create(cart.items,addressId:address,deliveryFee:1500);
   cart.items.clear();
   if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Commande créée.')));Navigator.pop(context);}
  }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
 }
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Panier')),body:cart.isEmpty?const Center(child:Text('Panier vide')):ListView(padding:const EdgeInsets.all(16),children:[
 ...cart.items.map((i)=>ListTile(title:Text(i.product.name),subtitle:Text('${i.product.price.toStringAsFixed(0)} FCFA × ${i.quantity}'),trailing:Row(mainAxisSize:MainAxisSize.min,children:[IconButton(onPressed:()=>setState(()=>cart.decrease(i.product)),icon:const Icon(Icons.remove)),Text('${i.quantity}'),IconButton(onPressed:()=>setState(()=>cart.add(i.product)),icon:const Icon(Icons.add))]))),
 Text('Total produits : ${cart.total.toStringAsFixed(0)} FCFA',style:const TextStyle(fontWeight:FontWeight.bold)),
 const SizedBox(height:12),const Text('Livraison : 1 500 FCFA'),const SizedBox(height:18),
 FilledButton(onPressed:checkout,child:const Text('Continuer vers la livraison'))
 ]));
}
