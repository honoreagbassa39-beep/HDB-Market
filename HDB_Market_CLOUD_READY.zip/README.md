# HDB Market — Version complète

Marketplace mobile Flutter pour Android + iPhone.

## Modules
- Authentification
- Catalogue produits
- Recherche et catégories
- Panier
- Commandes
- Adresses de livraison
- Frais de livraison
- Paiement sécurisé via Edge Function
- Suivi de commande
- Espace vendeur
- Stock
- Revenus vendeur
- Administration
- Notifications (structure)
- Multi-pays / devises

## Mise en route
1. Créer un projet Supabase.
2. Exécuter `supabase/schema.sql`.
3. Déployer les Edge Functions.
4. Configurer les secrets du prestataire de paiement côté serveur.
5. Lancer :
flutter pub get
flutter run --dart-define=SUPABASE_URL=TON_URL --dart-define=SUPABASE_PUBLISHABLE_KEY=TA_CLE

## Sécurité
Les clés secrètes de paiement et la clé service_role ne doivent jamais être embarquées dans l'application mobile.

## Production
Il reste à renseigner les identifiants réels du prestataire de paiement, le fournisseur de livraison et les comptes de publication Apple/Google. Aucun identifiant réel n'est inventé dans ce projet.
