create extension if not exists pgcrypto;

create table if not exists public.profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 phone text,
 role text not null default 'customer',
 country text default 'TG',
 created_at timestamptz not null default now()
);

create table if not exists public.products(
 id uuid primary key default gen_random_uuid(),
 seller_id uuid not null references auth.users(id) on delete cascade,
 name text not null,
 description text,
 category text,
 price numeric not null,
 stock integer not null default 0,
 image_url text,
 active boolean not null default true,
 created_at timestamptz not null default now()
);

create table if not exists public.addresses(
 id text primary key,
 user_id uuid not null references auth.users(id) on delete cascade,
 full_name text not null, phone text not null, country text not null,
 city text not null, district text not null, details text not null,
 created_at timestamptz not null default now()
);

create table if not exists public.orders(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 address_id text references public.addresses(id),
 total_amount numeric not null default 0,
 delivery_fee numeric not null default 0,
 status text not null default 'pending',
 tracking_code text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.order_items(
 id uuid primary key default gen_random_uuid(),
 order_id uuid not null references public.orders(id) on delete cascade,
 product_id uuid not null references public.products(id),
 quantity integer not null,
 unit_price numeric not null
);

create table if not exists public.payments(
 id uuid primary key default gen_random_uuid(),
 order_id uuid not null references public.orders(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 transaction_id text unique not null,
 provider text not null default 'cinetpay',
 amount numeric not null,
 currency text not null default 'XOF',
 status text not null default 'pending',
 provider_reference text,
 payment_url text,
 created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.addresses enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payments enable row level security;

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id,full_name,phone) values(new.id,new.raw_user_meta_data->>'full_name',new.raw_user_meta_data->>'phone') on conflict(id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create policy "public active products" on public.products for select using(active=true);
create policy "seller insert products" on public.products for insert to authenticated with check(auth.uid()=seller_id);
create policy "seller update products" on public.products for update to authenticated using(auth.uid()=seller_id);

create policy "own profile" on public.profiles for select to authenticated using(auth.uid()=id);
create policy "own address select" on public.addresses for select to authenticated using(auth.uid()=user_id);
create policy "own address insert" on public.addresses for insert to authenticated with check(auth.uid()=user_id);

create policy "own order select" on public.orders for select to authenticated using(auth.uid()=user_id);
create policy "own order insert" on public.orders for insert to authenticated with check(auth.uid()=user_id);
create policy "own item select" on public.order_items for select to authenticated using(exists(select 1 from public.orders o where o.id=order_id and o.user_id=auth.uid()));
create policy "own item insert" on public.order_items for insert to authenticated with check(exists(select 1 from public.orders o where o.id=order_id and o.user_id=auth.uid()));
create policy "own payment select" on public.payments for select to authenticated using(auth.uid()=user_id);
create policy "own payment insert" on public.payments for insert to authenticated with check(auth.uid()=user_id);
