import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
serve(async(req)=>{
 try{
  const {order_id}=await req.json();
  if(!order_id)return new Response(JSON.stringify({error:"order_id required"}),{status:400});
  // TODO production: authenticate user, load order server-side, verify ownership
  // and call the chosen payment provider using server-side secrets.
  return new Response(JSON.stringify({status:"pending",payment_url:null,order_id}),{headers:{"Content-Type":"application/json"}});
 }catch(e){return new Response(JSON.stringify({error:String(e)}),{status:500});}
});
