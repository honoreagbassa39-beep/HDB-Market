import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
serve(async(req)=>{
 try{
  const body=await req.json();
  // TODO: verify provider signature, locate payment by provider reference,
  // update payment and order only after authentic provider confirmation.
  return new Response(JSON.stringify({received:true}),{headers:{"Content-Type":"application/json"}});
 }catch(e){return new Response(JSON.stringify({error:String(e)}),{status:500});}
});
